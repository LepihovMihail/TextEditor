﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TextEditorLepihov22IS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK) //Проверяем был ли выбран файл
            {
                richTextBox.Clear(); //Очищаем richTextBox
                openFileDialog.Filter = "Text Files (*.txt)|*.txt"; //Указываем что нас интересуют
                //только текстовые файлы
                string fileName = openFileDialog.FileName; //получаем наименование файл и путь к
                //нему.
                richTextBox.Text = File.ReadAllText(fileName, Encoding.GetEncoding(1251)); //Передаем
                //содержимое файла в richTextBox
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            saveFileDialog.Filter = "Text Files|*.txt";//Задаем доступные расширения
            saveFileDialog.DefaultExt = ".txt"; //Задаем расширение по умолчанию
            //3
            if (saveFileDialog.ShowDialog() == DialogResult.OK) //Проверяем подтверждение 
                //сохранения информации.
{
                var name = saveFileDialog.FileName; //Задаем имя файлу
                File.WriteAllText(name, richTextBox.Text, Encoding.GetEncoding(1251)); //Записываем
                //в файл содержимое textBox с кодировкой 1251
}
            richTextBox.Clear();
        }

        private void выравниваниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Select(); // выравнивание только выделенного текста
                                  //richTextBox1.SelectAll(); //выделение всего текста
            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
            //richTextBox1.DeselectAll(); //Отмена выделения
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font myFont = new Font("Tahoma", 12, FontStyle.Regular, GraphicsUnit.Pixel);
            string Hello = "Hello World!";
            e.Graphics.DrawString(Hello, myFont, Brushes.Black, 20, 20);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCopy_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0)
                richTextBox.Copy();
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0) 
            {
                ColorDialog colorDialog = new ColorDialog();
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    richTextBox.SelectionColor= colorDialog.Color;
                }
            }
        }

        private void buttonCut_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
                richTextBox.Cut();
        }

        private void buttonHighlight_Click(object sender, EventArgs e)
        {
            richTextBox.SelectAll();
        }

        private void вырезатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText != "")
                richTextBox.Cut();
        }

        private void копироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectionLength > 0)
                richTextBox.Copy();
        }

        private void вставитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Clipboard.GetDataObject().GetDataPresent(DataFormats.Text)==true)
            {
                if (richTextBox.SelectionLength > 0)
                {
                    if (MessageBox.Show("Хотите ли вы вставить выбранный объект?", "Вырезать", MessageBoxButtons.YesNo) == DialogResult.No);
                    richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                richTextBox.Paste();
            }
        }

        private void buttonPaste_Click_1(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                if (richTextBox.SelectionLength > 0)
                {
                    if (MessageBox.Show("Хотите ли вы вставить выбранный объект?", "Вырезать", MessageBoxButtons.YesNo) == DialogResult.No) ;
                    richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.SelectionLength;
                }
                richTextBox.Paste();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
        }

        private void оПрограммеToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }
    }
}
